CREATE procedure change_payfee(did in number, paymoney in number,bankserial in varchar2,results out varchar2) is
 former_paydate number(8);
 former_bankcode char(2);
 former_balance number;
 former_cost number;
 former_pid number;
 today_date date;
 cursor rec_cursor is 
        select receivables.receive_id as rid from device inner join receivables 
        on device.device_id = receivables.device_id 
        where device.device_id=did and receivables.flag='1';
 cursor pay_cursor is 
       select pay_date, bank_code from payfee 
       where device_id=did and pay_money=paymoney 
         and bank_serial=bankserial and type='0000';
begin
  open pay_cursor;
  fetch pay_cursor into former_paydate,former_bankcode;
  select trunc(sysdate) into today_date from dual;
  if pay_cursor%notfound then
    results:='没有找到该条记录';
  else
    select balance into former_balance from device where device_id=did;
    if former_balance>=paymoney then
      update device set balance=former_balance-paymoney where device_id=did;
      results:='冲正成功';
      elsif to_char(former_paydate) != to_char(today_date,'yyyymmdd') then
        results:='不是本日缴费，无法冲正';
      else
        select count(*) into former_pid from payfee;
        insert into payfee values(former_pid+1,did,0-paymoney,former_paydate,former_bankcode,'1111',bankserial);
        for pay in rec_cursor loop
          update receivables set flag='0' where receive_id=pay.rid;
          end loop;
          select distinct cost_money into former_cost from pay_cost where pay_cost.device_id=did and pay_cost.cost_date=to_char(former_paydate);
          update device set balance=former_balance+former_cost-paymoney where device_id=did;
          results:='冲正成功';
    end if;
    
    end if;
    
end change_payfee;
/
