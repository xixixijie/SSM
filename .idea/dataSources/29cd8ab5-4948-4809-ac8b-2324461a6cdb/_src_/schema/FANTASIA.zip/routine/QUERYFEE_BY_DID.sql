CREATE procedure queryfee_by_did(did in number, sum_money out number) is
      basic_fee number(7,2);
      year_month receivables.yearmonth%type;
      de_type device.type%type;
      tempdate1 number; 
      tempdate2 number;
      re_id number;
      cursor de_cursor is
           select b.basicfee,b.yearmonth,a.type,b.receive_id
           from  device a, receivables b
           where  a.device_id = b.device_id
           and b.flag = 0
           and a.device_id=did;        
begin
      sum_money:=0;
      open de_cursor;
      loop
        fetch de_cursor into basic_fee,year_month,de_type,re_id;
        exit when de_cursor%notfound;
        sum_money:=sum_money+basic_fee;
        sum_money:=sum_money+basic_fee*0.08;
            
        if de_type = '01' then
           sum_money:=sum_money + basic_fee*0.1;
           else 
           sum_money:=sum_money + basic_fee*0.15;
          end if;
              
       select round(sysdate - to_date(year_month,'yyyymmdd')-1) 
       into tempdate1
       from dual;
       select to_number(to_char(sysdate,'DDD')) into tempdate2 from dual;
    
       if tempdate1 >0 then
         if de_type='01' then 
             sum_money:=sum_money+basic_fee*0.001*tempdate1;  
         else
              if tempdate1<tempdate2 then   
                   sum_money:=sum_money+basic_fee*tempdate1*0.002;
                else         
                   sum_money:=sum_money+basic_fee*(tempdate1-tempdate2)*0.002+basic_fee*(tempdate2)*0.003; 
            end if;
            end if;
        end if;
       end loop;
       close de_cursor;
end queryfee_by_did;
/
