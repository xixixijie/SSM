CREATE procedure check_detail(check_date in number) is
    d_today date;
    d_bankcode char(2);
    bank_payfee number(8,2);
    company_payfee number(8,2);
    bank_bankserial varchar2(20);
    company_bankserial varchar2(20);
    excep_count number;
    cursor detail_cursor is  
       select a.bank_code,a.payfee ,a.bank_serial,b.bank_serial,b.pay_money
       from bank_record a full outer join payfee b on a.bank_serial=b.bank_serial
      where b.bank_serial not in 
      (select bank_serial
      from  payfee  
      where type='1111') and b.pay_date=check_date or to_char(b.pay_date) is null
      and (a.pay_date=check_date or to_char(a.pay_date) is null);
begin
  select trunc(sysdate) into d_today from dual;
  select count(*) into excep_count from check_exception;
      open detail_cursor;
      loop
        
        fetch detail_cursor into d_bankcode,bank_payfee,bank_bankserial,company_bankserial,company_payfee;
        exit when detail_cursor%notfound;
        if(bank_bankserial is null) then
          excep_count:=excep_count+1;
          insert into check_exception values(excep_count,to_char(d_today,'yyyymmdd'),d_bankcode,bank_payfee,company_payfee,'银行无此流水号',company_bankserial);
     
          elsif(company_bankserial is null) then
                 excep_count:=excep_count+1;
                 insert into check_exception values(excep_count,to_char(d_today,'yyyymmdd'),d_bankcode,bank_payfee,company_payfee,'企业无此流水号',bank_bankserial);
                 elsif(bank_payfee!=company_payfee) then
                        excep_count:=excep_count+1;
                        insert into check_exception values(excep_count,to_char(d_today,'yyyymmdd'),d_bankcode,bank_payfee,company_payfee,'金额不等',company_bankserial);
         end if;
        end loop;
end check_detail;
/
