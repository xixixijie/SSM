CREATE procedure payfee_by_did(did in number,p_money in number,results out varchar) is
       p_date date;
       ran_num number;
       p_id number;
 
       p_id_char char(2);
       b_code payfee.bank_code%type;
       b_serial varchar2(20);
       d_balance number;
       total_pay_money number;
       de_smoney number;
      
        cursor payfee_cursor is 
        select receivables.receive_id as rid from device inner join receivables 
        on device.device_id = receivables.device_id 
        where device.device_id=did and receivables.flag='0';   
begin
       if p_money>0 then
         select trunc(sysdate) into p_date from dual;
         select trunc(dbms_random.value(1,4)) into ran_num from dual;
         select payfee_id into p_id 
         from (select payfee_id from payfee order by payfee_id desc) where rownum =1;
         if ran_num=1 then
           b_code:='01';
         elsif ran_num=2 then
           b_code:='02';
         elsif ran_num=3 then
           b_code:='03';
         elsif ran_num=4 then
           b_code:='04';  
           end if;
         
         p_id:=p_id+1;
         p_id_char:=to_char(p_id);
          b_serial:='YH'||to_char(p_date,'yyyymmdd')||p_id_char;
         insert into payfee values(p_id,did,p_money,to_char(p_date,'yyyymmdd'),b_code,'0000',b_serial);
         
          results:='缴费成功';
         else
          results:='缴费失败，缴费金额必须大于0';
      end if;
      
         select balance into d_balance from device where device.device_id=did;
         total_pay_money:=d_balance+p_money;
          queryfee_by_did(did,de_smoney);
          insert into pay_cost values(did,de_smoney,to_char(p_date,'yyyymmdd'));
      
     for pay in payfee_cursor loop
      
      if total_pay_money>=de_smoney then
        update receivables set flag='1' where receivables.receive_id=pay.rid;
      else
        exit;
        end if;
      end loop;
        total_pay_money:=total_pay_money-de_smoney;
         update device set balance=total_pay_money where device_id=did;
          
        
end payfee_by_did;
/
