CREATE procedure queryfee_by_cid(cid in client.client_id%type, sum_money out number) is
    did number;
    de_sum_money number;
    cursor cl_cursor is
           select b.device_id
           from client a, device b
           where a.client_id = b.client_id
           and a.client_id = cid;
begin
    sum_money:=0;
      open cl_cursor;
      loop
        fetch cl_cursor into did;
        exit when cl_cursor%notfound;
        queryfee_by_did(did,de_sum_money);
        sum_money:=sum_money+de_sum_money;
       end loop;
       close cl_cursor;
end queryfee_by_cid;
/
