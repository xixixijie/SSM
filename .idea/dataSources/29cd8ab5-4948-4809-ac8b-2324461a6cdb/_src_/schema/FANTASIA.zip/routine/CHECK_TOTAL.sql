CREATE procedure check_total(check_bankcode in char, total_count in number, total_payfee in number,check_date in varchar2,results out varchar2) is
    invalid_count number;
    real_count number;
    c_bankcode char(2);
    c_paydate number(8);
    c_totalfee number(7,2);
    c_totalcount number;
    cursor check_total_cursor is
           select bank_code,pay_date,sum(pay_money),count(*)
           from  payfee     
           where bank_code=check_bankcode and to_char(pay_date)=check_date    
           group by bank_code,pay_date;
              
begin
     select count(*) into  invalid_count
     from  payfee         
     where bank_code=check_bankcode and to_char(pay_date)=check_date and pay_money<0;
     open check_total_cursor;
     fetch check_total_cursor into c_bankcode,c_paydate,c_totalfee,c_totalcount;
     real_count:=c_totalcount-invalid_count*2;
     if real_count=total_count and c_totalfee=total_payfee then
         results:='对账成功';
       else
         results:='对账失败,请到明细对账表中查看明细';
         check_detail(c_paydate);
     end if;
end check_total;
/
